let User=require("./user");
const fs=require("fs");
const crypto=require("crypto");
const mongoClient=require("mongodb").MongoClient;
const client = require("./userLogin");
let flag=true;
let fName='';

let inspector={
    createUser:(req,resp)=>{
        let paramsObj=JSON.parse(Object.keys(req.body));

        if(!paramsObj.name||!paramsObj.password1||!paramsObj.password2||!paramsObj.email)
         return resp.status(400).json({error:"fill all the fields"});

         console.log("new user creation initiated...");

        let Name=paramsObj.name;
        let passw1=paramsObj.password1;
        let pass2=paramsObj.password2;
        let email=paramsObj.email;
        let institute=paramsObj.institute;
        let sha1,passwdHash;

        if(passw1!=pass2){ resp.json("passwords do not match"); return console.log("failed...");}
        else{  //encrpting password using sha1 algorithm
            sha1=crypto.createHash("sha1");
            sha1.update(paramsObj.password1);
           passwdHash=sha1.digest("hex");
        }


        const user={name:Name,password:passwdHash,email:email,institute:institute,loggedIn:true};
        insertUser(resp,user);//saving user
},
getFileName:()=>{
return fName;
}
}


//functions
async function insertUser(resp,document){
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="DustUser";
  const collectionName="c1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);
//checking if user exists
collection.findOne({name:document.name})
.then(data=>{
    try{
 if(data!=null) {
    console.log("user: "+data.name+" already exists...");
    flag=false; //alternative since promisereject is not working
    //return  PromiseRejectionEvent();
    }
else{console.log("creating new user...")}}
catch(e){ console.log("Error in sync:"+e)}}
)
.then(function(){
    if(flag==true){
     collection.insertOne(document);
    console.log("user has been created successfully...");
    createUserFile(document.name);
    resp.json({message:"user has been created successfully..."})
    }
    else{
        resp.json({error:"operation failed..."});
        console.log("operation aborted...");
    }
},()=>{
    resp.json({error:"operation failed..."});
    console.log("operation aborted...")})  
}

    catch(e){ //user exists
        if(e.code==11000) console.log("document key error,this user(document) already exists...");
        else console.log("An unknown error occured"+e);
    }
  
}


async function createUserFile(username){
    await fs.open("proxyPac/"+username+".json",'w',(err)=>{
        if(err) console.log("failed to create user file...");
        else{ 
            fName="proxyPac/"+username+".json";
            console.log("user filename set as..."+ inspector.getFileName());
        }
    })
}





module.exports=inspector;




