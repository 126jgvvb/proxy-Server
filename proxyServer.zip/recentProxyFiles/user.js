let mongoose=require("mongoose");
let passMongoose=require("passport-local-mongoose");
let schema=mongoose.Schema;

let userSchema=new schema({
    _id:{type:String,required:true},
    name:{type:String,required:true},
    email:{type:String},
    password:{type:String},
    institute:{type:String},
    loggedIn:{type:Boolean}
});

userSchema.plugin(passMongoose);

let user;
if(mongoose.models.User) user=mongoose.model("User");
else{user=mongoose.model("User",userSchema);}

module.exports=user;
