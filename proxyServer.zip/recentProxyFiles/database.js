const fs=require("fs");
const crypto=require("crypto");
const mongoClient=require("mongodb").MongoClient;

let inspector={
    createAgent:(req,resp)=>{
        let paramsObj=JSON.parse(Object.keys(req.body));

        if(!paramsObj.name||!paramsObj.date||!paramsObj.signature||!paramsObj.batch)
         return resp.status(400).json({error:"fill all the fields"});

         console.log("new Agent creation initiated...");

        let Name=paramsObj.name;
        let batch=paramsObj.batch;
        let catholic=paramsObj.catholic;
        let date=paramsObj.date;
        let signature=paramsObj.signature;

          //encrpting password using sha1 algorithm
            sha1=crypto.createHash("sha1");
            sha1.update(signature);
           passwdHash=sha1.digest("hex");

        const Agent={name:Name,signature:passwdHash,catholic:catholic,date:date,batch:batch};
        insertAgent(resp,user);//saving user
},
    deleteAgent:async function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));
        
        try{
            const client=new mongoClient("mongodb://localhost:27017");
            await client.connect();
    
      const dbName="certusAdmin";
      const collectionName="collection1";
    
      const db=client.db(dbName);
      const collection=db.collection(collectionName);

    //checking if user exists
    collection.findOne({name:paramsObj.name})
                .then(agent=>{
                    collection.deleteOne(agent);
                },()=>{})
                .then(()=>{
                    console.log("Agent deleted successfully...");
                    resp.status(200).json({message:"Deleting successfull..."});
                })
    }
    catch(e){
        console.log("Error ocurred: "+e);
    }
},
    updateDatabase:async function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));
        let count=paramsObj.length;

        try{
            const client=new mongoClient("mongodb://localhost:27017");
            await client.connect();
    
      const dbName="certusAdmin";
      const collectionName="collection1";
    
      const db=client.db(dbName);
      const collection=db.collection(collectionName);

    while(count>0){ //iterating thru each agent
    collection.findOne({name:paramsObj[count].name}) //checking if user exists
                .then(agent=>{
                  if(agent.name!=null)  collection.updateOne(paramsObj[count]); //updating existing users info
                  else  collection.insertOne(paramsObj[count]); //this a new agent 
                },()=>{});
                --count;
            }

            console.log("Data update complete...");
            resp.status(200).json({message:"Data update complete..."});
            //end of try statement
    }
    catch(e){
        console.log("Error ocurred: "+e);
    }

},
    getAgents:async function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));
        
        try{
            const client=new mongoClient("mongodb://localhost:27017");
            await client.connect();
    
      const dbName="certusAdmin";
      const collectionName="collection1";
    
      const db=client.db(dbName);
      const collection=db.collection(collectionName);

    //checking if user exists
    collection.find() //getting all agents
                .then(agents=>{
                    resp.status(200).json({data:agents}); //list of agents present
                },()=>{})
    }
    catch(e){
        console.log("Error ocurred: "+e);
    }
    }
}


//functions
async function insertAgent(resp,document){
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="certusAdmin";
  const collectionName="collection1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);
//checking if user exists
collection.findOne({name:document.name})
.then(data=>{
    try{
 if(data!=null) {
    console.log("Agent: "+data.name+" already exists...");
    flag=false; //alternative since promisereject is not working
    //return  PromiseRejectionEvent();
    }
else{console.log("creating new agent...")}}
catch(e){ console.log("Error in sync:"+e)}}
)
.then(function(){
    if(flag==true){
     collection.insertOne(document);
    console.log("Agent has been created successfully...");
    resp.json({message:"Agent has been created successfully..."})
    }
    else{
        resp.json({error:"operation failed..."});
        console.log("operation aborted...");
    }
},()=>{
    resp.json({error:"operation failed..."});
    console.log("operation aborted...")})  
}

    catch(e){ //user exists
        if(e.code==11000) console.log("document key error,this user(document) already exists...");
        else console.log("An unknown error occured"+e);
    }
  
}



module.exports=inspector;
