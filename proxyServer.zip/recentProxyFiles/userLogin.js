const mongoClient = require("mongodb").MongoClient;
const passport=require("passport");
const LocalStrategy=require("passport-local").Strategy;
const crypto=require("crypto");

const express=require("express");
const app=express();
app.use(passport.initialize());
app.use(passport.session());

//passport.use(new LocalStrategy(User.authenticate()));
//passport.use(User.authenticate);
//passport.serializeUser(User.serialize());
//passport.deserializeUser(User.deserializeUser());

let  client={
    confirmUser:async function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));
        console.log("user login initiated..."+Object.keys(req.body));

        try{
        if(!paramsObj.name||!paramsObj.password) return resp.status(400).json({message:"fill all the fields"});
        findUser(req,resp,paramsObj.name,paramsObj.password);
        }
        catch(e){console.log("error logging in: "+e)}
    },

    logoutUser:function(req,resp){
        let paramsObj=JSON.parse(Object.keys(req.body));

        LogOutUser(resp,paramsObj.name,paramsObj.password);
}
}


//functions
async function findUser(req,resp,username,password){  
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="DustUser";
  const collectionName="c1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);

//checking if user exists
collection.findOne({name:username})
.then(data=>{
 if(data.name!=null) {   //user exists
    //passwordverify(password,data.password)
   
    collection.findOne({name:username}) //use->{name:username,password}  care here ,users might have the same password,there4 the creteria is important
    .then(dat=>{
        if(dat.password!=null) { //waiting for the verify crypto function..
            sha1=crypto.createHash("sha1");
            sha1.update(password);
           passwdHash=sha1.digest("hex");

            if(passwdHash!=dat.password) PromiseRejectionEvent();

            if(dat.loggedIn==true){
                console.log("user already logged in...");
                resp.status(400).json({error:"This user is alreay logged in..."});
            }
                 else{
            collection.findOneAndUpdate({name:username},{$set:{loggedIn:true}})
            .then(()=>{
                console.log("user logged in successfully...");
                resp.json({message:"done"});
               // resp.sendFile(path.resolve("","proxyPac","chargedDust.html")); 
            });
        }
         }
        else PromiseRejectionEvent() },()=>{console.log("user doesnot exist...");resp.status(400).json("user doesnot exist")})
        .then(()=>{},()=>{
            console.log("invalid password...")
            resp.status(400).json({message:"invalid password"});
        })
    }
else PromiseRejectionEvent()})


    .then(()=>{},()=>{
        console.log("invalid username...")
        resp.status(400).json({message:"invalid username"});
    })

    }
    catch(e){
        console.log("error while logging in.."+e)
    }
}


async function LogOutUser(resp,username,password){
    try{
        const client=new mongoClient("mongodb://localhost:27017");
        await client.connect();

  const dbName="DustUser";
  const collectionName="c1";

  const db=client.db(dbName);
  const collection=db.collection(collectionName);
await collection.findOne({name:username})
                                .then(data=>{
                                    if(data.name!=null && data.password!=null){
                                        collection.findOneAndUpdate({name:username},{$set:{loggedIn:false}})
                                                    .then(()=>{
                                                        console.log("user logged out successfully..");
                                                        resp.json({message:"user logged out..."})
                                                    })
                                    }
                                    else PromiseRejectionEvent();
                                })
                                .then(()=>{},()=>{
                                    console.log("invalid username/password");
                                    resp.json({error:"invalid username/password"})
                                })

   
}
    catch(e){console.log("error while logging out:"+e)}
}



module.exports=client;





