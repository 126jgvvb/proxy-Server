const http=require("http"); //page running on http
const express=require("express");  //serving the proxy page
const bodyparser=require("body-parser"); //for json evaluation
const client=require("./userLogin");
const newUser=require("./userSignup");
const { Error } = require("mongoose");
const fs=require("fs");


const app=express();
app.use(bodyparser.urlencoded({extended:false}));
app.use(bodyparser.json());     //recieving json data
app.use(express.static("proxyPac"));    
const pageServer=http.createServer(app);

//readHiddenURLs(); //checking saved addresses


let fileData=''; //this is a reusable identifier throught
state1=false;//detecting if data is saved......coz  save(data) is not working
let empty=false;//,monitoring empty file
let file=null;
let content='';


/*******************proxy settings page***************/
module.exports=app.post("/login",(req,resp)=>{
    client.confirmUser(req,resp);
});

module.exports=app.post("/logout",(req,resp)=>{
    client.logoutUser(req,resp);
})


module.exports=app.post("/signup",(req,resp)=>{
newUser.createUser(req,resp);
});

module.exports=app.get("/",(req,resp)=>{
    resp.sendFile(path.resolve("","proxyPac","login.html"));
});

 module.exports=app.get("/Dust",(req,resp)=>{
        resp.sendFile(path.resolve("","proxyPac","chargedDust.html"));
     });

module.exports=app.post("/proxyPac/getFiles",(req,resp)=>{ //on document load retrieve the stored data
    let data=JSON.parse(Object.keys(req.body));
    readHiddenURLs(data.fileName);
    return resp.json(fileData);
})


module.exports=app.post("/proxyPac/saveData",async function(req,resp){  //new url brought
    let newData=JSON.parse(Object.keys(req.body)); //??..but works
console.log("***************************new address: "+newData.url);
await readHiddenURLs(newData.fileName);
if(empty==true) { 
  fileData='['+fileData.slice(1,fileData.lastIndexOf("]"))+'{"url":'+JSON.stringify(newData.url)+"}]";
}
//adding validation towards avoiding repeatition is recommended here
    else if(empty==false) fileData=fileData.slice(0,fileData.lastIndexOf("]")) +',{"url":'+JSON.stringify(newData.url)+"}]";  //adding to the existing data
await save(fileData,newData.fileName); //writing to disk

if(!state1) return resp.json(fileData); //state1==false if no error occured
else {
    resp.write("Error while saving data...try again later");
    state1=false;
}
})


module.exports=app.post("/proxyPac/removeData",async function(req,resp){  //deleting a url from the list
    let temp=JSON.parse(Object.keys(req.body));
    console.log("initiating removal of: "+temp.data[0].url); //important step
    await readHiddenURLs(temp.fileName);
    fileData=eval(fileData); //converting the string in filedata to an array of iterables

    let newFrozenURLs=[],state=false;
    for(let i=0; i<fileData.length; ++i){
        if(fileData.length==1) break; //one file in storage,just clean thus storing an empty array/file
       else if(!temp.data[1]){ //!temp[i] means a single object was brought{temp[0] only available},not an array
         if(fileData[i].url!=temp.data[0].url) newFrozenURLs.push(fileData[i]);
        }
        else{ //array brought?
            for (let j=0; j<temp.data.length; j++)  if(temp.data[j].url==fileData[i].url) state=true; //file found in delivery??
             if(!state) newFrozenURLs.push(fileData[i]); //if no match was found with this one(eg www.google.com) only
        }
    }
    if(newFrozenURLs.length<1) empty=true;

    newFrozenURLs=JSON.stringify(newFrozenURLs);
    console.log("filtered list==>"+newFrozenURLs);
    save(newFrozenURLs,temp.fileName);
    if(!state1){
        resp.json(newFrozenURLs);
    }
    else resp.write("Error while saving...try again later");
    state1=false; 
});


module.exports=function(){
    return newUser.getFileName();
}


/******************function definitions**************/
async function readHiddenURLs(fName=null){
    let fileName=fName==null?newUser.getFileName():"proxyPac/"+fName+".json";
    console.log("Reading files from: "+fileName);

    await fs.readFile(fileName,(error,data)=>{
        if(error) console.log("*********file read error: "+error);
        else{
            if(data.length<1){
                 console.log("file found empty...."+data);
                return;
                }
                else{
            content=Buffer.from(data,"ascii").toString("utf8");
            fileData=content;
                }

            if(content.length<3) return empty=true;
            else return empty=false; 
        }});

}



 function save(data,file){
    /*writing on disk*/
    try{
        if(data.length<1) throw new Error("unknown data leakage identified...cannot save");

      fs.writeFile("proxyPac/"+file+".json",data,(error)=>{
            if(error){
                console.log("*******************error while saving:"+error);
                state1=true;
                return false;
            }
            else{
                console.log("******************The new address has been saved successfully....");
                return true;
            }
        })
    }
    catch(e){console.log("***********************problem encoutered: "+e)}
}

function isLoggedIn(req,resp,state){
    if(req.isAuthenticated) return state=false; //authentication still  has issues here..ignore
    console.log("here"+req.isAuthenticated);
    resp.sendFile(path.resolve("","proxyPac","login.html"));
}


//graceful shutdown---research about this[events emitted when a process is stopped]
process.on("SIGTERM",()=>{
console.log("closing server...");

pageServer.close(()=>{
    let data=fs.createReadStream("hiddenURLs.json");
    data.pipe(fs.createWriteStream("saver.json"));
    process.exit(0);
});
})
//starting server
pageServer.listen(5000,()=>console.log("chargedDust says check settings at port 5000"));






