const net=require("net"); //for proxy functionality{http,https}
const fs=require("fs");  //filesystem
const proxySettings = require("./proxySettings");
const server=net.createServer();  //proxy server



/*****************implementing the proxy interface***********/
let serverPort=80;
let serverAddr;
let result=true;
let URLs_file=null,PORT=8000;
//readHiddenFiles();

//client connection
server.on("connection",(clientToproxySocket)=>{
    console.log("-----------------client connected to chargedDust proxy---------------");
    clientToproxySocket.once("data",data=>{  //listening once for the data present and collect it
        let tlsConnection=data.toString().indexOf("CONNECT")!==-1; //only true if conection is https
        
        //inspecting address
      if(data.toString().indexOf("isente")!==-1 ||  data.toString().indexOf("192.168")!==-1){
        console.log("closing server for data analysis...");
        server.close();
        console.log(":::::::::::::::::::::::::::::::::::::present data::::::::::::::::::::::::::\n"+data);
      }


        if(tlsConnection){ //connection is https
            serverPort=443;
            serverAddr=data.toString().split("CONNECT")[1].split(" ")[1].split(":")[0];
        }
        else{ //connection is http
            serverAddr=data.toString().split("Host:")[1].split("\n")[0];
        }

        console.log("***********Remote Address:"+serverAddr+"*****************");
        readHiddenFiles();
        check(serverAddr);
     
        if(result==true){ //checking address
          //creating connection btn proxy and destnation
       let dustToDsetination=net.createConnection({host:serverAddr,port:serverPort},()=>{
        console.log("-------------------dust connected to  the remote server---------------");
       });

       if(tlsConnection) clientToproxySocket.write("HTTP/1.1 200 OK\r\n\n");
       else dustToDsetination.write(data);

       //joining the ends together
       clientToproxySocket.pipe(dustToDsetination);
       dustToDsetination.pipe(clientToproxySocket);

       clientToproxySocket.on("error",(err)=>{
        console.log("-----------------client connection to dust failed------------");
        console.log(err);
       })

       dustToDsetination.on("error",(err)=>{
        console.log("---------------Dust connection to remote server failed-----------");
        console.log(err);
       })
    }
       else{
        console.log("!!!!!!!!!!!!!!!!!Access has been denied to this link!!!!!!!!!!!!!!!!!");
        result=true;
    }  
    })
});

//error
server.on("error",()=>{
    console.log("-----------------An internal error occured on chargedDust---------------");
});

//close
server.on("close",()=>{
    console.log("------------------client has disconnected from dust-----------------");
});


server.listen({host:'127.0.0.1',port:PORT},()=>console.log("chargedDust proxy running at port 8000"));


/******************function definitions**************/

//the simple illustration
function check(addr){
    if(URLs_file==null) return;
    for(let i=0; i<Number(URLs_file.length); ++i){
		if((URLs_file[i].url)==addr.toString().trim()){result=false; break;}
			}
            return result;
        }


        async function readHiddenFiles(){
            if(proxySettings()==''||undefined){
                console.log("No account set...");
                return;
            }
            else{
            await fs.readFile(proxySettings(),(error,data)=>{
                if(error) console.log("$$$$$$$$$$$file read error: "+error);
                else{
                    console.log("inspecting urls...........");
                    URLs_file=Buffer.from(data,"ascii").toString("utf8");
                    URLs_file=eval(URLs_file);
                }})
                if(URLs_file=='') return false;
        }
    }